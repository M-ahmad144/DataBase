﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Home
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            ListStudent();
        }
        private void ListStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DeleteData();
        }

        private void DeleteData()
        {
            using (var con = Configuration.getInstance().getConnection())
            {
                // Open the connection

                // Check if the registration number exists before deleting
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Student WHERE RegistrationNumber = @RegistrationNumber", con);
                checkCmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);

                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count > 0)
                {
                    // Registration number exists, proceed with deletion
                    SqlCommand deleteCmd = new SqlCommand("DELETE FROM Student WHERE RegistrationNumber = @RegistrationNumber", con);
                    deleteCmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);

                    int rowsAffected = deleteCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data deleted successfully.");



                    }
                    else
                    {
                        MessageBox.Show("Failed to delete data.");
                    }
                }


            }
            ListStudent();

        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void dataGridView1_CancelRowEdit(object sender, QuestionEventArgs e)
        {
            
        }
    }
}
