﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Home
{
    public partial class C_delete : Form
    {
        public C_delete()
        {
            InitializeComponent();
            ListStudent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DeleteData();
        }
        private void ListStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Course", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void DeleteData()
        {
            using (var con = Configuration.getInstance().getConnection())
            {
                // Open the connection

                // Check if the registration number exists before deleting
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Course WHERE Course_ID = @Course_ID", con);
                checkCmd.Parameters.AddWithValue("@Course_ID", textBox1.Text);

                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count > 0)
                {
                    // Registration number exists, proceed with deletion
                    SqlCommand deleteCmd = new SqlCommand("DELETE FROM Course WHERE Course_ID = @Course_ID", con);
                    deleteCmd.Parameters.AddWithValue("@Course_ID", textBox1.Text);

                    int rowsAffected = deleteCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data deleted successfully.");



                    }
                    else
                    {
                        MessageBox.Show("Failed to delete data.");
                    }
                }


            }
            ListStudent();

        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main();
            main.Show();
        }

        private void C_delete_Load(object sender, EventArgs e)
        {

        }
    }
}
