﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Home
{
    public partial class C_Search : Form
    {
        public C_Search()
        {
            InitializeComponent();
        }

        private void ListStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Course", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void RetrieveData()
        {
            var con = Configuration.getInstance().getConnection();


            if (con.State == ConnectionState.Open)  // Check if the connection is open
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Course WHERE Course_ID = @Course_ID", con);

                cmd.Parameters.AddWithValue("@Course_ID", textBox1.Text);

                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dataTable = new DataTable();
                dataTable.Load(reader);

                if (dataTable.Rows.Count > 0)
                {
                    // Display data in the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
                else
                {
                    MessageBox.Show("No data found for the specified registration number.");
                }


            }
            else
            {
                MessageBox.Show("Connection failed to open.");
            }
        }

        private void C_Search_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                RetrieveData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Courses form1 = new Courses();
            form1.Show();
        }
    }
}
