﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Home.Attendance
{
    public partial class MarkAttendance : Form
    {
        public MarkAttendance()
        {
            InitializeComponent();
            ListStudent();


        }

        private void Back_Click(object sender, EventArgs e)
        {
          this.Hide();
            Attendances attendances = new Attendances();
            attendances.Show();

        }

        private void MarkAttendance_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                

                SqlCommand cmd = new SqlCommand("Insert into ATTENDANCE_ values (@StudentRegNo, @CourseName, @TimeStamp, @Status)", con);

                // Assuming you want to insert the current date and time as TimeStamp
                cmd.Parameters.AddWithValue("@StudentRegNo", textBox1.Text);
                cmd.Parameters.AddWithValue("@CourseName", textBox2.Text);
                cmd.Parameters.AddWithValue("@TimeStamp", DateTime.Now); // Insert current date and time
                cmd.Parameters.AddWithValue("@Status",true);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                ListStudent();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving attendance record: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close(); // Ensure the connection is closed
            }
        }


        private void ListStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from ATTENDANCE_", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
