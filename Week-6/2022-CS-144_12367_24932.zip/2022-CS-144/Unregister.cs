﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Home.Enrollment
{
    public partial class Unregister : Form
    {
        public Unregister()
        {
            InitializeComponent();
            ListEnrollments();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Un_register();
        }
        private void ListEnrollments()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Enrollments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void Un_register()
        {
            using (var con = Configuration.getInstance().getConnection())
            {
                // Open the connection

                // Check if the registration number exists before deleting
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Enrollments WHERE StudentRegNo = @StudentRegNo AND CourseName = @CourseName", con);
                checkCmd.Parameters.AddWithValue("@StudentRegNo", textBox1.Text);
                checkCmd.Parameters.AddWithValue("@CourseName", textBox2.Text); // Adjust as needed

                int count = Convert.ToInt32(checkCmd.ExecuteScalar());

                if (count > 0)
                {
                    // Registration number exists, proceed with deletion
                    SqlCommand deleteCmd = new SqlCommand("DELETE FROM Enrollments WHERE StudentRegNo = @StudentRegNo AND CourseName = @CourseName", con);
                    deleteCmd.Parameters.AddWithValue("@StudentRegNo", textBox1.Text);
                    deleteCmd.Parameters.AddWithValue("@CourseName", textBox2.Text); // Adjust as needed

                    int rowsAffected = deleteCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete data.");
                    }
                }
            }

            ListEnrollments();
        }

        private void Unregister_Load(object sender, EventArgs e)
        {

        }

        private void Back_Click(object sender, EventArgs e)
        {
           this.Hide();
            Enroll enroll = new Enroll();
            enroll.Show();
        }
    }
}
