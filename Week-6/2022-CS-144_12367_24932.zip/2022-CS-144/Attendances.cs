﻿using Lab2_Home.Attendance;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Lab2_Home
{
    public partial class Attendances : Form
    {
        public Attendances()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {

            this.Hide();
            Main m = new Main();
            m.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MarkAttendance m=new MarkAttendance();
            m.Show();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           this.Hide();
            Edit edit = new Edit();
            edit.Show();
        }

        private void Attendances_Load(object sender, EventArgs e)
        {

        }
    }
}
