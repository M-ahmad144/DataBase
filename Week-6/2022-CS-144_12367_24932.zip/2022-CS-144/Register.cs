﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Lab2_Home.Enrollment
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
            ListStudent();
        }
        private void ListStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Enrollments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Enrollments values (@StudentRegNo,@CourseName)", con);
            cmd.Parameters.AddWithValue("@StudentRegNo", (textBox1.Text));
            cmd.Parameters.AddWithValue("@CourseName", (textBox2.Text));
           
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            ListStudent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Enroll en = new Enroll();
            en.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
