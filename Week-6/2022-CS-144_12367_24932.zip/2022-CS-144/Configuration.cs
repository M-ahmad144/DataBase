﻿using System;
using System.Data.SqlClient;

namespace Lab2_Home
{
    class Configuration
    {
        private static readonly string ConnectionStr = @"Data Source=(local);Initial Catalog=Lab2_Home;Integrated Security=True";
        private SqlConnection con;
        private static Configuration _instance;

        private Configuration()
        {
            con = new SqlConnection(ConnectionStr);
        }

        public static Configuration getInstance()
        {
            if (_instance == null)
                _instance = new Configuration();
            return _instance;
        }

        public SqlConnection getConnection()
        {
            if (con.State == System.Data.ConnectionState.Closed)
            {
                con.ConnectionString = ConnectionStr; // Set the connection string
                con.Open();
            }
            return con;
        }
    }
}
