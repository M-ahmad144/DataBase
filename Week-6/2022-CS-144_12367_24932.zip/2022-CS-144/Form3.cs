﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Lab2_Home
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            ListStudent();
        }
        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // Check if the event is for a specific column or row if needed
            int targetColumnIndex = 1; // Replace with the actual column index you want to track

            if (e.ColumnIndex == targetColumnIndex && e.RowIndex >= 0)
            {
                // Get the modified cell's value
                object newValue = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;

                // Perform actions based on the changed value
                 MessageBox.Show($"Cell value changed to: {newValue}");
            }
        }


        private void ListStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            UpdateStudentData();
        }




        private void UpdateStudentData()
        {
            
                using (SqlConnection con = Configuration.getInstance().getConnection())
                {
                    //con.Open();

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (!row.IsNewRow)
                        {
                            string registrationNumber = row.Cells["RegistrationNumber"].Value.ToString();
                            string name = row.Cells["Name"].Value.ToString();
                            string department = row.Cells["Department"].Value.ToString();
                        string session = row.Cells["Session"].Value.ToString();
                            string address = row.Cells["Address"].Value.ToString();

                            using (SqlCommand cmd = new SqlCommand("UPDATE Student SET Name = @Name, Department = @Department, Session = @Session, Address = @Address WHERE RegistrationNumber = @RegistrationNumber", con))
                            {
                                cmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                                cmd.Parameters.AddWithValue("@Name", name);
                                cmd.Parameters.AddWithValue("@Department", department);
                                cmd.Parameters.AddWithValue("@Session", session);
                                
                                cmd.Parameters.AddWithValue("@Address", address);

                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    MessageBox.Show("Update successful.");
                }
            
            
        }


        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }

        private void dataGridView1_CancelRowEdit(object sender, QuestionEventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
